﻿namespace Entidades
{
    public class Turma
    {
        public string Identificacao { get; set; }
        public Pessoa[] pessoas { get; set; }

    }
}
