﻿using Entidades;
using System.Text;

namespace EscolaCRM
{
    public static class Program
    {
        public static void Main(string[] args)
        {
            #region MyRegion

            Estudante joaozinho = new Estudante();
            joaozinho.Nome = "Joaozinho";
            joaozinho.NumeroRegistro = 1;
            joaozinho.DataNascimento = new DateTime(2019, 01, 01);
            joaozinho.EnderecoEletronico = "joao@gmail.com";

            Console.WriteLine(" Nome: " + joaozinho.Nome +
                              " idade: " + joaozinho.ObterIdade() +
                              " dataNascimento:" + joaozinho.DataNascimento +
                              " emailValido: " + joaozinho.ValidarEnderecoEletronico());

            var valor = "1234";
            var valor2 = "4321";

            Console.WriteLine(Convert.ToInt32(valor) + Convert.ToInt32(valor2));




            Estudante mariazinha = new Estudante { Nome = "Mariazinha", DataNascimento = new DateTime(2018, 12, 12), NumeroRegistro = 2 };


            var idadeJoaozinho = joaozinho.ObterIdade();
            var idadeMariazinha = mariazinha.ObterIdade();

            var somatorioIdades = idadeJoaozinho + idadeMariazinha;
            Console.WriteLine(somatorioIdades);

            ///Sobrecarga /Overload
            ///   ++operator;

            Console.WriteLine(joaozinho.Nome + mariazinha.Nome);






            var exemplo = "nome do exemplo";
            var exemplo02 = true;
            var exemplo03 = 140;
            var exemplo04 = 100000000000000000000000000000000000001f;

            var pedrinho = new Estudante { Nome = "Pedrinho" };
            pedrinho.Nome = "Pedrinho de novo";


            StringBuilder sb = new StringBuilder();
            sb.Append("Inicio");
            sb.Append(" da ");
            sb.Append(" minha ");
            sb.Append(" frase ");

            var minhaVar = sb.ToString();



            var turmaExemplo = new Turma();
            turmaExemplo.Identificacao = "Turma Exemplo";
            turmaExemplo.pessoas = new Pessoa[3];
            turmaExemplo.pessoas[0] = joaozinho;
            turmaExemplo.pessoas[1] = mariazinha;
            turmaExemplo.pessoas[2] = pedrinho;

            #endregion


            //for
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine(i);
            }

            for (int i = 0; i < turmaExemplo.pessoas.Length; i++)
            {
                Console.WriteLine(turmaExemplo.pessoas[i].Nome);
            }

            //while
            int quantidadePessoas = turmaExemplo.pessoas.Length;
            int contador = 0;
            while (contador < quantidadePessoas)
            {
                Console.WriteLine(turmaExemplo.pessoas[contador].Nome);
                contador++;
            }

            //contador aqui = 3
            //do while
            do
            {
                //Por acaso imprime pedrinho por causa do -1
                Console.WriteLine(turmaExemplo.pessoas[contador - 1].Nome);
                contador++;
            } while (contador < quantidadePessoas);

            //foreach
            foreach (var pessoa in turmaExemplo.pessoas)
            {
                Console.WriteLine(pessoa.Nome);
            }


            //Switch
            var numero = 1;

            switch (numero)
            {
                case 1:
                    Console.WriteLine("Numero = 1");
                    break;
                case 2:
                    Console.WriteLine("Numero = 2");
                    break;
                case 3:
                    Console.WriteLine("Numero = 3");
                    break;
                default:
                    Console.WriteLine("Certeza que é numero?");
                    break;
            }


            Console.ReadLine();
        }
    }
}
