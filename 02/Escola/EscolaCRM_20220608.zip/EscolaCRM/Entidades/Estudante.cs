﻿namespace Entidades
{
    public class Estudante : Pessoa
    {
        public Turma Turma { get; set; }
    }
}
