﻿namespace Entidades
{
    public class Professor : Pessoa
    {
        public string Especialidade { get; set; }
    }
}
